simstrat-aed
============